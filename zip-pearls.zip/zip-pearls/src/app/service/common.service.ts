import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor(private http: HttpClient,
    @Inject('BASE_URL') private baseUrl: string,) { }


  loadMealsforonemen(): Observable<any> {
    var url = this.baseUrl + "api/meals";
    return this.http.post<any>(url, {});
  }
}

