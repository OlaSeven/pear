import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delivery-menu',
  templateUrl: './delivery-menu.component.html',
  styleUrls: ['./delivery-menu.component.css']
})
export class DeliveryMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
